package com.example.backend.services;

import com.example.backend.entities.Users;

public interface UserService extends BaseService<Users, Long> {
    
}
