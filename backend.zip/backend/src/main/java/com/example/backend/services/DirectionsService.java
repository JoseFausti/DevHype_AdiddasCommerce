package com.example.backend.services;

import com.example.backend.entities.Directions;

public interface DirectionsService extends BaseService<Directions, Long>{
    
}
