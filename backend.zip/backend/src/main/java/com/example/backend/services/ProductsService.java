package com.example.backend.services;

import com.example.backend.entities.Products;

public interface ProductsService extends BaseService<Products, Long>{
    
}
