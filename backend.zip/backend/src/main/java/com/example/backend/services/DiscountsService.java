package com.example.backend.services;

import com.example.backend.entities.Discounts;

public interface DiscountsService extends BaseService<Discounts, Long>{
    
}
