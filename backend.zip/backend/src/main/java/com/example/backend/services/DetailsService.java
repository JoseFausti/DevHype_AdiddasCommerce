package com.example.backend.services;

import com.example.backend.entities.Details;

public interface DetailsService extends BaseService<Details, Long>{
    
}
