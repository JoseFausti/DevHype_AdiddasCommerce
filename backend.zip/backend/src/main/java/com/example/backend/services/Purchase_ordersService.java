package com.example.backend.services;

import com.example.backend.entities.Purchase_orders;

public interface  Purchase_ordersService extends BaseService<Purchase_orders, Long>{
    
}
